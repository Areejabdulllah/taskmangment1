//
//  File.swift
//  
//
//  Created by Alhanouf Abdullah Alatif  on 15/08/1445 AH.
//

import Foundation
import Fluent
import Vapor

struct TaskController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let tasks = routes.grouped("Task_1")
        tasks.get(use: index)
        tasks.post(use: create)
        tasks.group(":taskID") { tasks in
            tasks.delete(use: delete)
        }
    }

    func index(req: Request) async throws -> [task] {
        try await task.query(on: req.db).all()
    }

 
    func create(req: Request) async throws -> task {
        do {
            let tasks = try req.content.decode(task.self)
            try await tasks.save(on: req.db)
            return tasks
        } catch {
            // Log the detailed error message
            req.logger.error("\(String(reflecting: error))")
            throw error // rethrow the error to be handled by Vapor's default error middleware
        }
    }

    
    func delete(req: Request) async throws -> HTTPStatus {
        guard let task = try await task.find(req.parameters.get("taskID"), on: req.db) else {
            throw Abort(.notFound)
        }
        try await task.delete(on: req.db)
        return .noContent
    }
}
